var mongoose=require('mongoose');
var Schema=mongoose.Schema;
var astrobankdetail=new Schema({
    username:{
        type:String,
        default:" "
    },
    name:{
        type:String,
        default:" "
    },
    accountnumber:{
        type:String,
        default:" "
    },
    accountname:{
        type:String,
        default:" "
    },
    bankname:{
        type:String,
        default:" "
    },
    ifsccode:{
        type:String,
        default:" "
    },
    branchname:{
        type:String,
        default:" "
    },
    pincode:{
        type:String,
        default:" "
    }
    
},{timestamps:true});

var astrobankdetails=mongoose.model('astrobankdetail',astrobankdetail);
module.exports=astrobankdetails;