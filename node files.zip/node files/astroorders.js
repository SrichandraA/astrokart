var mongoose=require('mongoose');
var Schema=mongoose.Schema;

var astroorder=new Schema({
userusername:String,
astrousername:String,
usersname:String,
astrosname:String,
service:String,
rate:String,
 status:{
        type:String,
        default:"pending"
    }
    
},{timestamps:true});

var astroorders=mongoose.model('astroorder',astroorder);
module.exports=astroorders;
