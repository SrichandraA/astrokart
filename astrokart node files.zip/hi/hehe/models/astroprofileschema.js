var mongoose=require('mongoose');
var Schema=mongoose.Schema;

var astrodetail=new Schema({
    
    username:{
        type:String,
        default:" "
    },
    password:{
        type:String,
        default:" "
    },
    name:{
        type:String,
        default:" "
    },
    gender:{
        type:String,
        default:" "
    },
    age:{
        type:Number,
        default:0
    },
    location:{
        type:String,
        default:" "
    },
    TOK:{
        type:String,
        default:" "
    },
    mobile:{
        type:String,
        default:" "
    }
});

var astrodetails=mongoose.model('astrodetail',astrodetail);
module.exports=astrodetails;