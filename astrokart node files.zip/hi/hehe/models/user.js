var mongoose=require('mongoose');
var passportLocalMongoose=require('passport-local-mongoose');
var Schema=mongoose.Schema;

var user=new Schema({
   username:String,
    password:String
});

user.plugin(passportLocalMongoose);

var users=mongoose.model('user',user);
module.exports=users;