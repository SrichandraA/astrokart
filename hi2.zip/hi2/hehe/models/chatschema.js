var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var chatschema = new Schema({
    
    msg:String
    
},{
    timestamps : true
});

var chatschema=mongoose.model('chatschema',chatschema);
module.exports=chatschema;