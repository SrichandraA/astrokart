var express = require('express');
var path = require('path');
var favicon = require('serve-favicon');
var logger = require('morgan');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');
var mongoose=require('mongoose');
var passport=require('passport');
var LocalStrategy=require('passport-local').Strategy;
  var  mailer = require('express-mailer');


var config=require('./config');
mongoose.connect(config.mongoUrl);
var db = mongoose.connection;
db.on('error', console.error.bind(console, 'connection error:'));
db.once('open', function () {
    // we're connected!
    console.log("Connected correctly to server");
});

var index = require('./routes/index');
var userorders=require('./routes/userordersroute');
var astroorders=require('./routes/astroordersroute');
var astrologers=require('./routes/astrousers');
var userdetails=require('./routes/userdetails');
var users = require('./routes/users');
var pro=require('./routes/profile');
var useraccount=require('./routes/useraccdetails');
var astrologerdetails=require('./routes/astrodetails');

var app = express();

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'jade');

// uncomment after placing your favicon in /public
//app.use(favicon(path.join(__dirname, 'public', 'favicon.ico')));
app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(cookieParser());

var User=require('./models/user');
app.use(passport.initialize());
var AstroUser=require('./models/astroschema');
passport.use('user',new LocalStrategy(User.authenticate()));
passport.use('astrouser',new LocalStrategy(AstroUser.authenticate()));

/*passport.serializeUser(function(user, done) {            
  if (isUser(user)) {
    // serialize user
      passport.serializeUser(User.serializeUser());

  } else if (isAstroUser(user)) {
    // serialize company
      passport.serializeUser(AstroUser.serializeUser());

  }
});*/

passport.serializeUser(User.serializeUser());

passport.deserializeUser(User.deserializeUser());
app.use(express.static(path.join(__dirname, 'public')));

mailer.extend(app, {
  from: 'chandra.urfrnd@gmail.com',
  host: 'smtp.gmail.com', // hostname 
  secureConnection: true, // use SSL 
  port: 465, // port for secure SMTP 
  transportMethod: 'SMTP', // default is SMTP. Accepts anything that nodemailer accepts 
  auth: {
    user: 'chandra.urfrnd@gmail.com',
    pass: 'ap31bt7921'
  }
});

app.post('/send', function (req, res, next) {
  app.mailer.send('email', {
    to: req.body.email, // REQUIRED. This can be a comma delimited string just like a normal email to field.  
    subject: 'nee yabba', // REQUIRED. 
      text: 'That was easy!',
    otherProperty: 'Other Property' // All additional properties are also passed to the template as local variables. 
  }, function (err) {
    if (err) {
      // handle error 
      console.log(err);
      res.send('There was an error sending the email');
      return;
    }
    res.send('Email Sent');
  });
});




app.use('/', index);

app.use('/users', users);
app.use('/astrousers',astrologers);
app.use('/userorders',userorders);
app.use('/astroorders',astroorders);
app.use('/profile',pro);
app.use('/useraccount',useraccount);
app.use('/userdetails',userdetails);
app.use('/astrodetails',astrologerdetails);

// catch 404 and forward to error handler
app.use(function(req, res, next) {
  var err = new Error('Not Found');
  err.status = 404;
  next(err);
});

// error handler
app.use(function(err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});

module.exports = app;
