
module.exports = {
    'secretKey': '12345-67890-09876-54321',
    'mongoUrl' : 'mongodb://srichandra:astrokart203@ds023674.mlab.com:23674/astrokartuser'
}