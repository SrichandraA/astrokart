var mongoose=require('mongoose');
var Schema=mongoose.Schema;

var useraccount=new Schema({
    
    userid:String,
    DOB:{
        type:Date,
        default:Date.now
    },
    POB:String,
    mobile:Number,
    pic:Buffer
    
},{timestamps:true});

var useracc=mongoose.model('useracc',useraccount);
module.exports=useracc;
