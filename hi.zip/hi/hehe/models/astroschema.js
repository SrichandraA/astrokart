var mongoose=require('mongoose');
var passportLocalMongoose=require('passport-local-mongoose');
var Schema=mongoose.Schema;

var astrouser=new Schema({
   username:String,
     email:String,
    password:String
   
});

astrouser.plugin(passportLocalMongoose);

var astrousers=mongoose.model('astrouser',astrouser);
module.exports=astrousers;