var mongoose=require('mongoose');
var Schema=mongoose.Schema;

var userorder=new Schema({
   username:String,
    about:String,
    description:String
    
},{timestamps:true});

var userorders=mongoose.model('userorder',userorder);
module.exports=userorders;
