var mongoose=require('mongoose');
var Schema=mongoose.Schema;

var astrodetail=new Schema({
    
    username: {
        type:String,
        default:" ",
        unique : true, 
        required : true, 
        dropDups: true
    },
    
    name:{
        type:String,
        default:" "
    },
    bio:{
        type:String,
        default:" "
    },
     email:{
        type:String,
        default:" "
    },
    gender:{
        type:String,
        default:" "
    },
    age:{
        type:String,
        default:" "
    },
    location:{
        type:String,
        default:" "
    },
    TOK:{
        type:String,
        default:" "
    },
    rating:{
        type:Number,
        default:0
    },
    
    mobile:{
        type:String,
        default:" "
    },
    pic:{
        type:String,
        default:" "
    }
});

var astrodetails=mongoose.model('astrodetail',astrodetail);
module.exports=astrodetails;