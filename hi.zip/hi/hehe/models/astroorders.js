var mongoose=require('mongoose');
var Schema=mongoose.Schema;

var astroorder=new Schema({
userusername:String,
astrousername:String,
usersname:String,
astrosname:String,
service:String,
rate:String
    
},{timestamps:true});

var astroorders=mongoose.model('astroorder',astroorder);
module.exports=astroorders;
