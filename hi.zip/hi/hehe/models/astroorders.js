var mongoose=require('mongoose');
var Schema=mongoose.Schema;

var astroorder=new Schema({
   username:String,
    about:String,
    description:String
    
},{timestamps:true});

var astroorders=mongoose.model('astroorder',astroorder);
module.exports=astroorders;
