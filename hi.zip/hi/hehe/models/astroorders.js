var mongoose=require('mongoose');
var Schema=mongoose.Schema;

var astroorder=new Schema({
userusername:String,
astrousername:String,
usersname:String,
astrosname:String,
service:String,
rate:String,
 status:{
        type:String,
        default:"pending"
    },
    name1:String,
    DOB1:String,
    TOB1:String,
    POB1:String,
    gender1:String,
    description:String,
    name2:String,
    DOB2:String,
    TOB2:String,
    POB2:String,
    gender2:String,
    email:String,
    mobile:String
    
},{timestamps:true});

var astroorders=mongoose.model('astroorder',astroorder);
module.exports=astroorders;
