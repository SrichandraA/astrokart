var express=require('express');
var bodyParser=require('body-parser');

var pschema=require('../models/userdetails');
var Verify=require('./verify');

var router=express.Router();
router.use(bodyParser.json());

router.route('/')

.get(function(req,res,next){
    
    pschema.find({},function(err,pro){
        if(err) throw err;
        console.log('profiles are');
        res.send(pro);
    });
})
.post(function(req,res,next){
    
    pschema.create(req.body,function(err,pro){
        
        if(err) throw err;
        var id=pro._id;
        res.writeHead(200,{'Content-type':'text/plain'});
        res.end('profile created');
    });
});
router.route('/:id')
.get(function (req, res, next) {
    pschema.find({"username":req.params.id}, function (err, pro) {
        if (err) throw err;
        
        //res.writeHead(200,{'Content-type':'text/plain'});
        res.send(pro);
    });
})
.put(function(req,res,next){

	pschema.findOneAndUpdate({name:req.params.name}, {

		$set:req.body
	},{
		new:true
	},function(err,pro){

		if(err) throw err;
		console.log('updated');
		res.json(pro);
	});
});


module.exports=router;