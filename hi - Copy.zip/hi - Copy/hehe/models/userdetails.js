var mongoose=require('mongoose');
var Schema=mongoose.Schema;
var prodetails=new Schema({
    username:{
        type:String,
        default:" "
    },
    password:{
        type:String,
        default:" "
    },
    name:{
        type:String,
        default:" "
    },
    DOB:{
        type:String,
        default:" "
    },
    
    gender:{
        type:String,
        default:" "
    },
    POB:{
        type:String,
        default:" "
    },
    TOB:{
        type:String,
        default:" "
    },
    email:{
        type:String,
        default:" "
    },
    mobile:{
        type:String,
        default:" "
    },
    pic:{
        type:String,
        default:" "
    }
    
},{timestamps:true});

var userdetails=mongoose.model('userdetails',prodetails);
module.exports=userdetails;